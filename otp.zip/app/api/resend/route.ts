import { ruangotp } from '@/lib/ruangotp'
export async function POST(req: Request){ const {order_id}=await req.json(); const res=await ruangotp.resend(order_id); return Response.json(res.data) }